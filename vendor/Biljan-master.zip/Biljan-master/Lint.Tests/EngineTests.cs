﻿using System;
using System.IO;
using System.Text;
using Lint.Exceptions;
using NUnit.Framework;

namespace Lint.Tests
{
    [TestFixture]
    public class EngineTests
    {
        [TestCase("integer", 5, 5)]
        [TestCase("floats", 1.1, 1.1)]
        [TestCase("boolean", true, true)]
        [TestCase("nilVariable", null, null)]
        [TestCase("string", "Hello World", "Hello World")]
        [TestCase("emptystring", "", "")]
        public void Indexer_GetGlobal_IsCorrect(string globalName, object value, object expectedValue)
        {
            using (var engine = new Engine())
            {
                engine[globalName] = value;
                Assert.AreEqual(expectedValue, engine[globalName]);
            }
        }

        [Test]
        public void Constructor_NewState_IsCorrect()
        {
            using (var engine = new Engine())
            {
                Assert.AreNotEqual(IntPtr.Zero, engine.StatePointer);
            }
        }

        [Test]
        public void CreateFunction_DisposedEngine_ThrowsObjectDisposedException()
        {
            using (var engine = new Engine())
            {
                engine.Dispose();
                Assert.Throws<ObjectDisposedException>(() => engine.CreateFunction(string.Empty));
            }
        }

        [Test]
        public void CreateFunction_NullChunk_ThrowsArgumentNullException()
        {
            using (var engine = new Engine())
            {
                Assert.Throws<ArgumentNullException>(() => engine.CreateFunction(luaChunk: null));
            }
        }

        [Test]
        public void CreateFunction_SomeError_ThrowsLuaScriptException()
        {
            using (var engine = new Engine())
            {
                Assert.Throws<LuaScriptException>(() => engine.CreateFunction("function(a, b) return a or b end"));
            }
        }

        [Test]
        public void CreateTable_DisposedEngine_ThrowsObjectDisposedException()
        {
            using (var engine = new Engine())
            {
                engine.Dispose();
                Assert.Throws<ObjectDisposedException>(() => engine.CreateTable());
            }
        }

        [Test]
        public void CreateTable_IsCorrect()
        {
            using (var engine = new Engine())
            {
                var table = engine.CreateTable();
                Assert.NotNull(table);
            }
        }

        [Test]
        public void CreateTable_NegativeNumberOfOtherElements_ThrowsArgumentOutOfRangeException()
        {
            using (var engine = new Engine())
            {
                Assert.Throws<ArgumentOutOfRangeException>(() => engine.CreateTable(numberOfOtherElements: -1));
            }
        }

        [Test]
        public void CreateTable_NegativeNumberOfSequentialElements_ThrowsArgumentOutOfRangeException()
        {
            using (var engine = new Engine())
            {
                Assert.Throws<ArgumentOutOfRangeException>(() => engine.CreateTable(-1));
            }
        }

        [Test]
        public void DoFile_DisposedEngine_ThrowsObjectDisposedException()
        {
            using (var engine = new Engine())
            {
                engine.Dispose();
                Assert.Throws<ObjectDisposedException>(() => engine.DoFile(string.Empty));
            }
        }

        [Test]
        public void DoFile_InvalidFile_ThrowsFileNotFoundException()
        {
            using (var engine = new Engine())
            {
                Assert.Throws<FileNotFoundException>(() => engine.DoFile("test"));
            }
        }

        [Test]
        public void DoFile_InvalidFileExtension_ThrowsLuaException()
        {
            var filePath =
                Path.Combine(Path.GetDirectoryName(new Uri(typeof(EngineTests).Assembly.CodeBase).LocalPath),
                    "temp.txt");

            using (var engine = new Engine())
            using (var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.ReadWrite))
            {
                fileStream.Close();
                Assert.Throws<LuaException>(() => engine.DoFile(fileStream.Name));
                File.Delete(filePath);
            }
        }

        [Test]
        public void DoFile_IsCorrect()
        {
            var filePath =
                Path.Combine(Path.GetDirectoryName(new Uri(typeof(EngineTests).Assembly.CodeBase).LocalPath),
                    "temp.lua");

            using (var engine = new Engine())
            using (var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.ReadWrite))
            {
                var fileContent = @"
                                    function getSum(x, y)
                                        return x + y
                                    end
                                    result = 0
                                    for i = 1, 10, 2 do
                                        result = result + i
                                    end
                                    result = getSum(result, 1)
                                    return result";
                var buffer = Encoding.UTF8.GetBytes(fileContent);
                fileStream.Write(buffer, 0, buffer.Length);
                fileStream.Close();

                var results = engine.DoFile(fileStream.Name);
                Assert.AreEqual(1, results.Length);
                Assert.AreEqual(26, results[0]);

                File.Delete(filePath);
            }
        }

        [Test]
        public void DoFile_NullFilePath_ThrowsArgumentNullException()
        {
            using (var engine = new Engine())
            {
                Assert.Throws<ArgumentNullException>(() => engine.DoFile(null));
            }
        }

        [Test]
        public void DoString_DisposedEngine_ThrowsObjectDisposedException()
        {
            using (var engine = new Engine())
            {
                engine.Dispose();
                Assert.Throws<ObjectDisposedException>(() => engine.DoString("a = 5"));
            }
        }

        [Test]
        public void DoString_InvalidSyntax_ThrowsLuaScriptException()
        {
            using (var engine = new Engine())
            {
                Assert.Throws<LuaScriptException>(() => engine.DoString("a = 5b"));
            }
        }

        [Test]
        public void DoString_MultipleResults_IsCorrect()
        {
            using (var engine = new Engine())
            {
                var results = engine.DoString("return 1, 2, 3, 4, 5");
                var expected = new[] {1, 2, 3, 4, 5};
                Assert.AreEqual(expected, results);
            }
        }

        [Test]
        public void DoString_NoResults_ReturnsEmpty()
        {
            using (var engine = new Engine())
            {
                var results = engine.DoString("a = 5");
                Assert.IsEmpty(results);
            }
        }

        [Test]
        public void DoString_NullChunk_ThrowsArgumentNullException()
        {
            using (var engine = new Engine())
            {
                Assert.Throws<ArgumentNullException>(() => engine.DoString(null));
            }
        }

        [Test]
        public void DoString_OneResult_IsCorrect()
        {
            using (var engine = new Engine())
            {
                var result = engine.DoString("return 5")[0];
                Assert.AreEqual(5, result);
            }
        }

        [Test]
        public void Indexer_GetGlobalFromDisposedEngine_ThrowsObjectDisposedException()
        {
            using (var engine = new Engine())
            {
                engine.Dispose();
                Assert.Throws<ObjectDisposedException>(() => engine["test"].ToString());
            }
        }

        [Test]
        public void Indexer_SetGlobalOnDisposedEngine_ThrowsObjectDisposedException()
        {
            using (var engine = new Engine())
            {
                engine.Dispose();
                Assert.Throws<ObjectDisposedException>(() => engine["test"] = null);
            }
        }

        //[Test]
        //public void PullObjectFromStack_DisposedEngine_ThrowsObjectDisposedException()
        //{
        //    using (var engine = new Engine())
        //    {
        //        engine.Dispose();
        //        Assert.Throws<ObjectDisposedException>(() => engine.PullObjectFromStack(0));
        //    }
        //}

        //[Test]
        //public void PushObjectToStack_DisposedEngine_ThrowsObjectDisposedException()
        //{
        //    using (var engine = new Engine())
        //    {
        //        engine.Dispose();
        //        Assert.Throws<ObjectDisposedException>(() => engine.PushObjectToStack(null));
        //    }
        //}

        [Test]
        public void SuccessiveDispose_IsCorrect()
        {
            using (var engine = new Engine())
            {
                engine.Dispose();
                engine.Dispose();
            }
        }
    }
}