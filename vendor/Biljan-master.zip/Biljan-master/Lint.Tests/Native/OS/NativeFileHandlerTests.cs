﻿using System;
using System.Diagnostics.CodeAnalysis;
using Lint.Native.OS;
using NUnit.Framework;

namespace Lint.Tests.Native.OS
{
    [TestFixture]
    [SuppressMessage("ReSharper", "ObjectCreationAsStatement")]
    public sealed class NativeFileHandlerTests
    {
        [Test]
        public void Constructor_InvalidFileOrImage_ThrowsBadImageFormatException()
        {
            Assert.Throws<BadImageFormatException>(() => new FunctionLoader("nunit"));
        }

        [Test]
        public void Constructor_NullFilePath_ThrowsArgumentNullException()
        {
            Assert.Throws<ArgumentNullException>(() => new FunctionLoader(null));
        }
    }
}