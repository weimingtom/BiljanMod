﻿using System;
using Lint.Exceptions;
using NUnit.Framework;

namespace Lint.Tests.Native
{
    [TestFixture]
    public class LuaCoroutineTests
    {
        [Test]
        public void CreateCoroutine_DisposedInterpreter_ThrowsObjectDisposedException()
        {
            using (var interpreter = new Engine())
            {
                interpreter.Dispose();
                Assert.Throws<ObjectDisposedException>(() => interpreter.CreateCoroutine(null));
            }
        }

        [Test]
        public void CreateCoroutine_NullFunction_ThrowsArgumentNullException()
        {
            using (var interpreter = new Engine())
            {
                Assert.Throws<ArgumentNullException>(() => interpreter.CreateCoroutine(null));
            }
        }

        //[Test]
        //public void Resume_CoroutineReturnsArgumentsFromResume_IsCorrect()
        //{
        //    using (var interpreter = new Engine())
        //    {
        //        interpreter.DoString(@"co = coroutine.create(function (a,b,c)
        //                                        return a, b, c
        //                                    end)");
        //        var coroutine = (LuaCoroutine) interpreter["co"];
        //        interpreter.PushObjectToStack(2);
        //        interpreter.PushObjectToStack(3.3);

        //        var (_, _, results) = coroutine.Resume(2);
        //        Assert.AreEqual(3, results.Length);
        //        Assert.AreEqual(new object[] {2, 3.3, null}, results);
        //    }
        //}

        [Test]
        public void Resume_DeadCoroutine_ThrowsLuaException()
        {
            using (var interpreter = new Engine())
            {
                var function = interpreter.CreateFunction("return 0");
                var coroutine = interpreter.CreateCoroutine(function);
                var (success, errorMsg, _) = coroutine.Resume(0);

                Assert.IsTrue(success);
                Assert.Null(errorMsg);

                Assert.Throws<LuaException>(() => coroutine.Resume(0));
            }
        }

        [Test]
        public void Resume_ReturnsSomething_IsCorrect()
        {
            using (var interpreter = new Engine())
            {
                var function = interpreter.CreateFunction("return 1, 3.3, 5, 'test', false");
                var coroutine = interpreter.CreateCoroutine(function);
                var (success, _, results) = coroutine.Resume(0);

                Assert.IsTrue(success);
                Assert.AreEqual(5, results.Length);
                Assert.AreEqual(new object[] {1, 3.3, 5, "test", false}, results);
            }
        }

        [Test]
        public void Resume_TooManyArguments_ThrowsLuaException()
        {
            using (var interpreter = new Engine())
            {
                var function = interpreter.CreateFunction("return ...");
                var coroutine = interpreter.CreateCoroutine(function);

                Assert.Throws<LuaException>(() => coroutine.Resume(1000000000));
            }
        }

        [Test]
        public void Resume_YieldReturnsResultToResume_IsCorrect()
        {
            using (var interpreter = new Engine())
            {
                var function = interpreter.CreateFunction(@"
                                                            for i = 1, 10 do
                                                                coroutine.yield(i)
                                                            end");
                var coroutine = interpreter.CreateCoroutine(function);

                for (var i = 1; i <= 10; ++i)
                {
                    var (_, _, results) = coroutine.Resume(0);
                    Assert.AreEqual(1, results.Length);
                    Assert.AreEqual(i, results[0]);
                }

                coroutine.Resume(0);
                Assert.Throws<LuaException>(() => coroutine.Resume(0));
            }
        }
    }
}