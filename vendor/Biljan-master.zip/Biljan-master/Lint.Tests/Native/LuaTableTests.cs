﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Lint.Tests.Native
{
    [TestFixture]
    public class LuaTableTests
    {
        [TestCase("x", 10)]
        [TestCase("y", 15)]
        [TestCase("float", 5.5F)]
        [TestCase("color", "blue")]
        public void Add_IsCorrect(string key, object value)
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                table.Add(key, value);
                Assert.AreEqual(value, table[key]);
            }
        }

        [TestCase("x", 10)]
        [TestCase("y", 15)]
        [TestCase("float", 5.5F)]
        [TestCase("color", "blue")]
        public void Remove_IsCorrect(string key, object value)
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();

                table[key] = value;
                Assert.AreEqual(value, table[key]);

                table.Remove(key);
                Assert.IsNull(table[key]);
            }
        }

        [TestCase("x", 10)]
        [TestCase("y", 15)]
        [TestCase("float", 5.5F)]
        [TestCase("color", "blue")]
        public void Indexer_GetSetValue_IsCorrect(string key, object value)
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                table[key] = value;
                Assert.AreEqual(value, table[key]);
            }
        }

        [Test]
        public void AddRange_IsCorrect()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                var kvps = new[]
                {
                    new KeyValuePair<string, object>("x", 20),
                    new KeyValuePair<string, object>("y", 5.5),
                    new KeyValuePair<string, object>("color", "black")
                };

                table.AddRange(kvps);
                Assert.IsTrue(kvps.All(kvp => table[kvp.Key] != null));
            }
        }

        [Test]
        public void AddRange_NullArray_ThrowsArgumentNullException()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                Assert.Throws<ArgumentNullException>(() => table.AddRange(null));
            }
        }

        [Test]
        public void Clear_IsCorrect()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                table.Add("testbool", true);
                table.Clear();
                Assert.IsNull(table["testbool"]);
            }
        }

        [Test]
        public void ContainsKey_IsCorrect()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                table.Add("testbool", true);
                Assert.IsTrue(table.ContainsKey("testbool"));
                Assert.IsFalse(table.ContainsKey("teststring"));
            }
        }

        [Test]
        public void CopyTo_InsufficientSize_ThrowsArgumentException()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                table["0"] = "test1";
                table["1"] = "test2";
                var array = new KeyValuePair<string, object>[2];
                Assert.Throws<ArgumentException>(() => table.CopyTo(array, 1));
            }
        }

        [Test]
        public void CopyTo_InvalidIndex_ThrowsIndexOutOfRangeException()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                var array = new KeyValuePair<string, object>[3];
                Assert.Throws<ArgumentOutOfRangeException>(() => table.CopyTo(array, -2));
                Assert.Throws<ArgumentOutOfRangeException>(() => table.CopyTo(array, 5));
            }
        }

        [Test]
        public void CopyTo_IsCorrect()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                table["0"] = "test1";
                table["1"] = "test2";

                var array = new KeyValuePair<string, object>[3];
                table.CopyTo(array, 1);
                Assert.AreEqual(array.Skip(1), table);
            }
        }

        [Test]
        public void CopyTo_NullArray_ThrowsArgumentNullException()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                Assert.Throws<ArgumentNullException>(() => table.CopyTo(null, 0));
            }
        }

        [Test]
        public void GetEnumerator_IsCorrect()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                var kvps = new[]
                {
                    new KeyValuePair<string, object>("color", "black"),
                    new KeyValuePair<string, object>("x", 15),
                    new KeyValuePair<string, object>("y", 5.5F)
                };

                table.AddRange(kvps);
                Assert.AreEqual(kvps, table.OrderBy(kvp => kvp.Key));
            }
        }

        [Test]
        public void Indexer_GetSetInnerTable_IsCorrect()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                var innerTable = interpreter.CreateTable();
                table["innerTable"] = innerTable;
                Assert.AreSame(innerTable, table["innerTable"]);
            }
        }

        [Test]
        public void Indexer_NonExistantKvp_ReturnsNull()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                Assert.IsNull(table["key"]);
            }
        }

        [Test]
        public void Keys_HasValues_IsNotEmpty()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                table.Add("testbool", true);
                Assert.IsNotEmpty(table.Keys);
            }
        }

        [Test]
        public void Keys_NoValues_IsEmpty()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                Assert.IsEmpty(table.Keys);
            }
        }

        [Test]
        public void Metatable_NoMetatable_ReturnsNull()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                Assert.IsNull(table.Metatable);
            }
        }

        [Test]
        public void Metatable_SomeMetatable_ReturnsTable()
        {
            using (var interpreter = new Engine())
            {
                var metatable = interpreter.CreateTable();
                var table = interpreter.CreateTable().WithMetatable(metatable);
                Assert.AreSame(metatable, table.Metatable);
            }
        }

        [Test]
        public void TryGetValue_IsCorrect()
        {
            using (var interpreter = new Engine())
            {
                var table = interpreter.CreateTable();
                table.Add("testbool", true);
                Assert.IsTrue(table.TryGetValue("testbool", out _));
                Assert.IsFalse(table.TryGetValue("teststring", out _));
            }
        }
    }
}