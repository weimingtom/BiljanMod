﻿using System;
using System.Diagnostics;
using Lint.Debugging;
using Lint.Exceptions;
using Lint.Native;
using NUnit.Framework;

namespace Lint.Tests.Native
{
    [TestFixture]
    public class LuaFunctionTests
    {
        public string Test(string test) => test;

        [TestCase(new object[] {true, false})]
        [TestCase(new object[] {"test string"})]
        [TestCase(1, 2, 3, 4, 5)]
        [TestCase("various types", 1, 2.2, true)]
        public void Call_MultipleResults_IsCorrect(object[] args)
        {
            using (var interpreter = new Engine())
            {
                var function = interpreter.CreateFunction("return ...");
                var results = function.Call(args);

                Assert.AreEqual(args.Length, results.Length);
                Assert.AreEqual(args, results);
            }
        }

        [TestCase("Hello, World")]
        public void CreateFunction_FromCSharpDelegate_IsCorrect(string input)
        {
            using (var engine = new Engine())
            {
                var function = engine.CreateFunction(new Func<string, string>(Test));
                engine["test"] = function;
                Assert.AreEqual(input, function.Call(new object[] {input})[0]);
                Assert.AreEqual("Hello", engine.DoString("return test('Hello')")[0]);
            }
        }

        [Test]
        public void Call_ExtraArgumentsShouldGetAdjusted_IsCorrect()
        {
            using (var interpreter = new Engine())
            {
                var function = interpreter.CreateFunction(@"
                                    function add(x, y) 
                                        return x +  y 
                                    end
                                    return add(...)");
                Debug.WriteLine(function == null);
                for (var i = 0; i < 20; ++i)
                {
                    LuaLibrary.LuaRawGetI(interpreter.StatePointer, -1001000, i);
                }

                DebugHelper.DumpStack(interpreter.StatePointer);
                var result = function.Call(new object[] {5, 3, 7, 15, 3})[0];

                Assert.AreEqual(8, result);
            }
        }

        [Test]
        public void Call_NoResults_IsCorrect()
        {
            using (var interpreter = new Engine())
            {
                var function = interpreter.CreateFunction("a = 5");
                var results = function.Call();

                Assert.IsEmpty(results);
                Assert.AreEqual(5, interpreter["a"]);
            }
        }

        [Test]
        public void Call_NumberOfResultsShouldGetAdjusted_IsCorrect()
        {
            using (var interpreter = new Engine())
            {
                var function = interpreter.CreateFunction("return 1, 2, 3, 4, 5");
                var results = function.Call(null, 3);

                Assert.AreEqual(3, results.Length);
                Assert.AreEqual(new[] {1, 2, 3}, results);

                results = function.Call(null, -3);

                Assert.AreEqual(5, results.Length);
                Assert.AreEqual(new[] {1, 2, 3, 4, 5}, results);

                results = function.Call(null, 6);

                Assert.AreEqual(6, results.Length);
                Assert.AreEqual(new object[] {1, 2, 3, 4, 5, null}, results);
            }
        }

        [Test]
        public void Call_SingleResult_IsCorrect()
        {
            using (var interpreter = new Engine())
            {
                var function = interpreter.CreateFunction("return 5");
                var results = function.Call();

                Assert.AreEqual(1, results.Length);
                Assert.AreEqual(5, results[0]);
            }
        }

        [Test]
        public void CreateFunction_CSharpDelegateIsNull_ThrowsArgumentNullException()
        {
            using (var engine = new Engine())
            {
                Assert.Throws<ArgumentNullException>(() => engine.CreateFunction(@delegate: null));
            }
        }

        [Test]
        public void CreateFunction_CSharpMethodInfoIsNull_ThrowsArgumentNullException()
        {
            using (var engine = new Engine())
            {
                Assert.Throws<ArgumentNullException>(() => engine.CreateFunction(methodInfo: null));
            }
        }

        [Test]
        public void CreateFunction_DisposedInterpreter_ThrowsObjectDisposedException()
        {
            using (var interpreter = new Engine())
            {
                interpreter.Dispose();
                Assert.Throws<ObjectDisposedException>(() => interpreter.CreateFunction(string.Empty));
            }
        }

        [Test]
        public void CreateFunction_InvalidChunk_ThrowsLuaScriptException()
        {
            using (var interpreter = new Engine())
            {
                Assert.Throws<LuaScriptException>(() => interpreter.CreateFunction("a = "));
            }
        }

        [Test]
        public void CreateFunction_NullChunk_ThrowsArgumentNullException()
        {
            using (var interpreter = new Engine())
            {
                Assert.Throws<ArgumentNullException>(() => interpreter.CreateFunction(luaChunk: null));
            }
        }
    }
}