# Lint
A .NET application which allows bidirectional communication between Lua and C Sharp. The project targets .NET Framework 4.8 and can run only on Windows and Linux operating systems.

## Features
- Targets .NET Framework 4.8
- Supports Lua 5.3
- .NET -> Lua context switching
- Lua -> .NET context switching
- Subscribing to .NET events through Lua

## Examples
To get started, you need to construct a new instance of the `Engine` class. The `Engine` class is a wrapper around Lua's C API and creating a new instance produces a new Lua state for your app to run on.

```csharp
var engine = new Engine();
```

or

```csharp
using (var engine = new Engine())
{
}
```

All Lua interop is done within the main Lua state that gets created along with the engine. Once the engine is disposed memory cleanup takes place and all objects get destroyed.

## Mutating Lua's global environment
Lint utilizes indexers to retrieve or modify the contents of Lua's global environment:

```csharp
using (var engine = new Engine())
{
    // Set and print the value of global 'x'
    engine["x"] = 25;
    Console.WriteLine($"The value of 'x' is {engine["x"]}");
}
```

## Evaluating Lua chunks
You may execute Lua chunks by passing them as arguments to the `DoString` method. The results (if any) are passed back in form of an array of `object`s when the function returns. As with Lua's C API, you can adjust the number of results by specifying an optional parameter. The results are pushed in direct order (meaning the first result is at index 0).
```csharp
using (var engine = new Engine())
{
    // Set and print the value of global 'x'
    engine["x"] = 25;
    Console.WriteLine($"The value of 'x' is {engine["x"]}");

    // Evaluate the following expression: return 25
    var result = engine.DoString("return 25")[0];
    Console.WriteLine(result);
}
```

## Creating Lua types
Complex Lua types (tables, functions, and coroutines) are represented as objects in Lint which provide an easy and efficient way of managing them.

### Functions
The `CreateFunction` method allows you to create reusable Lua functions (note that functions can also be returned as results from the `DoString` method). These functions can be called at any time by invoking the `Call` method:
```csharp
using (var engine = new Engine())
{
    // Set and print the value of global 'x'
    engine["x"] = 25;
    Console.WriteLine($"The value of 'x' is {engine["x"]}");

    // Evaluate the following expression: return 25
    var result = engine.DoString("return 25")[0];
    Console.WriteLine(result);

    // Create Lua functions
    var additionFunction = interpreter.CreateFunction(@"
                      function add(x, y) 
                          return x + y 
                      end
                      return add(...)");
    var factorialFunction = (LuaFunction) engine.DoString("return function(x) for i=x-1,1 do x=x*i");
    var additionResult = additionFunction.Call(new object[] { 5, 3 })[0]; // Returns 8
    var factorialResult = factorialFunction.Call(new object[] {5}); // Returns 120
}
```

Furthermore, the `Engine` class provides a few convenient overloads that let you create Lua functions from C# delegates and method signatures:
```csharp
using (var engine = new Engine())
{
    // Set and print the value of global 'x'
    engine["x"] = 25;
    Console.WriteLine($"The value of 'x' is {engine["x"]}");

    // Evaluate the following expression: return 25
    var result = engine.DoString("return 25")[0];
    Console.WriteLine(result);

    // Create a Lua function that will run the specified Lua chunk
    var additionFunction = interpreter.CreateFunction(@"
                      function add(x, y) 
                          return x + y 
                      end
                      return add(...)");
    // Get the function returned by the specified Lua chunk
    var factorialFunction = (LuaFunction) engine.DoString("return function(x) for i=x-1,1 do x=x*i");
    var additionResult = additionFunction.Call(new object[] { 5, 3 })[0]; // Returns 8
    var factorialResult = factorialFunction.Call(new object[] {5}); // Returns 120

    // Create a Lua function that will execute a specific delegate
    var delegateFunction = engine.CreateFunction(new Func<long, long, double>(DivisonMethod));
    // Or use a method signature: 
     var functionFromSignature = engine.CreateFunction(typeof(SomeType).GetMethod("MethodName"));
    Console.WriteLine($"1 / 5 = {delegateFunction.Call(new object[] {1, 5})}");

    double DivisionMethod(long x, long y) => (double) x / y;
}
```

### Coroutines
Coroutines are created by calling the `CreateCoroutine` method. In order to construct a coroutine, you must specifiy the function which the coroutine will execute. As far as functionality goes, they work just like native Lua coroutines: they can yield, resume, invoke subroutines etc.
```csharp
using (var engine = new Engine())
{
    // Set and print the value of global 'x'
    engine["x"] = 25;
    Console.WriteLine($"The value of 'x' is {engine["x"]}");

    // Evaluate the following expression: return 25
    var result = engine.DoString("return 25")[0];
    Console.WriteLine(result);

    // Create a Lua function that will run the specified Lua chunk
    var additionFunction = interpreter.CreateFunction(@"
                      function add(x, y) 
                          return x + y 
                      end
                      return add(...)");
    // Get the function returned by the specified Lua chunk
    var factorialFunction = (LuaFunction) engine.DoString("return function(x) for i=x-1,1 do x=x*i");
    var additionResult = additionFunction.Call(new object[] { 5, 3 })[0]; // Returns 8
    var factorialResult = factorialFunction.Call(new object[] {5}); // Returns 120

    // Create a Lua function that will execute a specific delegate
    var delegateFunction = engine.CreateFunction(new Func<long, long, double>(DivisonMethod));
    // Or use a method signature: 
     var functionFromSignature = engine.CreateFunction(typeof(SomeType).GetMethod("MethodName"));
    Console.WriteLine($"1 / 5 = {delegateFunction.Call(new object[] {1, 5})}");

    // Create a Lua coroutine
    var function = engine.CreateFunction(@"
                                           for i = 1, 10 do
                                               coroutine.yield(i)
                                           end");
    var coroutine = engine.CreateCoroutine(function);

    double DivisionMethod(long x, long y) => (double) x / y;
}
```

Coroutines are started/resumed by invoking the `Resume` method. The `Resume` method returns a `ValueTuple<bool, string, object[]>` -- these values represent the success status, an error message (`null` if none) and the results respectively. Results are either return values or values passed to a `yield` call:
```csharp
using (var engine = new Engine())
{
    // Set and print the value of global 'x'
    engine["x"] = 25;
    Console.WriteLine($"The value of 'x' is {engine["x"]}");

    // Evaluate the following expression: return 25
    var result = engine.DoString("return 25")[0];
    Console.WriteLine(result);

    // Create a Lua function that will run the specified Lua chunk
    var additionFunction = interpreter.CreateFunction(@"
                      function add(x, y) 
                          return x + y 
                      end
                      return add(...)");
    // Get the function returned by the specified Lua chunk
    var factorialFunction = (LuaFunction) engine.DoString("return function(x) for i=x-1,1 do x=x*i");
    var additionResult = additionFunction.Call(new object[] { 5, 3 })[0]; // Returns 8
    var factorialResult = factorialFunction.Call(new object[] {5}); // Returns 120

    // Create a Lua function that will execute a specific delegate
    var delegateFunction = engine.CreateFunction(new Func<long, long, double>(DivisonMethod));
    // Or use a method signature: 
     var functionFromSignature = engine.CreateFunction(typeof(SomeType).GetMethod("MethodName"));
    Console.WriteLine($"1 / 5 = {delegateFunction.Call(new object[] {1, 5})}");

    // Create a Lua coroutine
    var function = engine.CreateFunction(@"
                                           for i = 1, 10 do
                                               coroutine.yield(i)
                                           end");
    var coroutine = engine.CreateCoroutine(function);
    for (var i = 1; i <= 10; ++i)
    {
        var (_, _, results) = coroutine.Resume(0);
        Console.WriteLine($"Results: {results.Length}"); // Always 1
        Console.WriteLine($"Current: {results[0]}"); // Equals to the value of i
    }

    coroutine.Resume(0);

    double DivisionMethod(long x, long y) => (double) x / y;
}
```

### Tables
Lua tables are implemented as an `IDictionary<string, object>`, which means that all table values are key/value pairs. Tables follow Lua's semantics, meaning that values either have key names or implicit indices assigned to them (example: `local table = {x=10, y=45; "one", "two", "three"}` The first two values are represented by keys "x" and "y" (respectively), the remaining values are automatically assigned an index starting from 1). You may create tables by invoking the `CreateTable` method:
```csharp
using (var engine = new Engine())
{
    // Set and print the value of global 'x'
    engine["x"] = 25;
    Console.WriteLine($"The value of 'x' is {engine["x"]}");

    // Evaluate the following expression: return 25
    var result = engine.DoString("return 25")[0];
    Console.WriteLine(result);

    // Create a Lua function that will run the specified Lua chunk
    var additionFunction = interpreter.CreateFunction(@"
                      function add(x, y) 
                          return x + y 
                      end
                      return add(...)");
    // Get the function returned by the specified Lua chunk
    var factorialFunction = (LuaFunction) engine.DoString("return function(x) for i=x-1,1 do x=x*i");
    var additionResult = additionFunction.Call(new object[] { 5, 3 })[0]; // Returns 8
    var factorialResult = factorialFunction.Call(new object[] {5}); // Returns 120

    // Create a Lua function that will execute a specific delegate
    var delegateFunction = engine.CreateFunction(new Func<long, long, double>(DivisonMethod));
    // Or use a method signature: 
     var functionFromSignature = engine.CreateFunction(typeof(SomeType).GetMethod("MethodName"));
    Console.WriteLine($"1 / 5 = {delegateFunction.Call(new object[] {1, 5})}");

    // Create a Lua coroutine
    var function = engine.CreateFunction(@"
                                           for i = 1, 10 do
                                               coroutine.yield(i)
                                           end");
    var coroutine = engine.CreateCoroutine(function);
    for (var i = 1; i <= 10; ++i)
    {
        var (_, _, results) = coroutine.Resume(0);
        Console.WriteLine($"Results: {results.Length}"); // Always 1
        Console.WriteLine($"Current: {results[0]}"); // Equals to the value of i
    }

    coroutine.Resume(0);

    // Create a Lua table
    var table = engine.CreateTable();
    table["0"] = "test1";
    table["NamedKey"] = "test2";

    double DivisionMethod(long x, long y) => (double) x / y;
}
```

## Exposing .NET Types and Assemblies
You can instruct the engine to load a specific type, namespace, or even assembly into the Lua context. This will allow you to access imported types by reffering to their global names.
You can import types and assemblies either by calling one of the following mehods from the .NET environment:

```csharp
using (var engine = new Engine())
{
    engine.ImportType(typeof(Int32), "int"); // Import the 'Int32' type as 'int'
    engine.ImportNamespace("System"); // Import the whole 'System' namespace
    engine.LoadAssembly(typeof(ExampleType).Assembly); // Load an assembly
}
```
or by calling their Lua equivalents within Lua itself (`import_type`, `import_namespace`, `load_assembly`).

### Constructing imported types
Imported types are constructed by calling the global value that represents the type:
In order to construct an instance of a specified type you must call its global name:

```lua
local exampleString = String('!', 3)
print(exampleString) // Prints "!!!"
```

In order to construct a generic type, you must use the following protocol: first, you invoke the generic type definition with the desired type arguments (these arguments must match the type parameters in number, order, and type). This will construct a closed generic type. Once complete, you must invoke the closed type and provide its arguments (optional). Example:

```lua
local queue = Queue(Int32)(5)
```

The following table illustrates the previous example a bit more in-depth:
| Generic Type Definition  | Type Argument(s)  | Constructed (closed) type  |  Closed type instance | 
|---|---|---|---|---|
| Queue()  | Int32  | Queue(Int32) | Queue(Int32)(arguments passed to `Queue<Int32>()` constructor)  | 

### Manipulating type members
The followng example demonstrates the modification and retrieval of type members from within Lua:

```lua
SomeType.Property = nil
int_minval = Int32.MinValue
short_maxval = Int16.MaxValue

print(int_minval) -- Prints -2147483648
print(short_maxval) -- Prints 32767
```

When it comes to method invocation, static methods follow the same syntax C# uses, wheareas instance methods use Lua's `:` notation:

```lua
import('System', true)
success, parsed_val = Double.TryParse("123.456", _) -- C#'s 'out' parameters should be ignored as they're returned as results
dotnetinstance:Test()
print(succes, parsed_val) -- Prints true, 123.456
```

Generic methods are a special case. In order to invoke a generic method you must abide by the same syntax rules as with generic type construction.

## Hiding Type Members and Specifying Global Functions
Type members can be rendered invisible to the Lua runtime by applying the `LuaHideAttribute`:

```csharp
public class TestClass
{
    [LuaHide]
    public string HiddenString = "m67p"; 
    
    public string MyString => "Test";
    
    [LuaHide]
    public void HiddenMethod()
    {
        /*...*/
    }
}
```

Conversely, methods can be flagged as global Lua functions by applying the `LuaGlobalAttribute`. The engine scans the whole AppDomain upon state creation in order to identify and import these methods. The type that defines global methods is left unimported, however.

## Using the .NET Event System
Lint allows subscribing to .NET events through Lua. In order to subscribe to an event you must index the desired event and invoke the `Register` function, passing a Lua function as an event handler. 

```lua
import('TestType', false)

function eventhandler(sender, args)
  print('Lua event handler invoked.')
end

TestType.StaticEvent:Register(eventhandler)
```

At the moment, Lint is only compatible with events of type `void(object, TEventArgs)`.

# Roadmap
The following needs to be completed on this project:
- [x] Linux support
- [x] Make the code DRY
- [x] Stack cleanup on various operations
- [x] Implement a reference cleanup mechanism
- [x] Allow storing .NET object instances
- [x] A .NET event handling mechanism
- [x] Generic method invocation
- [x] .NET object manipulation through Lua
- [X] Work out a better overload resolution algorithm (should also include extension methods)
