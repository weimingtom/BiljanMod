﻿using System;
using JetBrains.Annotations;

namespace Lint.Attributes
{
    /// <summary>
    ///     Indicates that the marked element is hidden (inaccessible) from the Lua runtime.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Event | AttributeTargets.Field | AttributeTargets.Method |
                    AttributeTargets.Property)]
    [PublicAPI]
    public sealed class LuaHideAttribute : Attribute
    {
    }
}